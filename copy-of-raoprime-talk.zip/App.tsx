import React, { useState, useEffect } from 'react';
import { AppMode, Persona } from './types';
import { PERSONAS } from './constants';
import TextChat from './components/TextChat';
import VoiceChat from './components/VoiceChat';
import { Search, Battery, Wifi, Signal, SquarePen, ChevronDown, BadgeCheck } from 'lucide-react';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.CONTACTS);
  const [activePersona, setActivePersona] = useState<Persona | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState<'primary' | 'general'>('primary');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: false });
  };

  const startText = (persona: Persona) => {
    setActivePersona(persona);
    setMode(AppMode.TEXT);
  };

  const handleBack = () => {
    setMode(AppMode.CONTACTS);
    setActivePersona(null);
  };

  const VerifiedBadge = ({ size = "w-3.5 h-3.5" }: { size?: string }) => (
    <BadgeCheck className={`${size} fill-[#0095F6] text-white stroke-[2px]`} />
  );

  // --- Render Active Mode ---
  if (mode === AppMode.TEXT && activePersona) {
    return (
      <TextChat 
        persona={activePersona} 
        onBack={handleBack} 
        onVoiceCall={() => setMode(AppMode.VOICE)} 
        currentTime={currentTime} 
      />
    );
  }

  if (mode === AppMode.VOICE && activePersona) {
    return <VoiceChat persona={activePersona} onBack={handleBack} currentTime={currentTime} />;
  }

  // --- Instagram DM List Style Interface ---
  return (
    <div className="h-[100dvh] w-full bg-black text-white flex justify-center overflow-hidden font-sans">
      <div className="w-full max-w-md h-full bg-black flex flex-col relative">
        
        {/* Status Bar */}
        <div className="px-6 pt-3 pb-2 flex justify-between items-center text-[15px] font-semibold tracking-wide z-20 bg-black safe-top">
           <span className="w-[54px] text-center font-medium">{formatTime(currentTime)}</span>
           <div className="flex gap-1.5 items-center">
             <Signal className="w-4 h-4 fill-white" />
             <Wifi className="w-4 h-4" />
             <div className="relative flex items-center gap-1">
                <span className="text-xs font-bold">85%</span>
                <div className="relative">
                   <Battery className="w-6 h-6 text-white" />
                   <div className="absolute top-[7px] left-[2.5px] w-[13px] h-[9px] bg-white rounded-[1px]"></div>
                </div>
             </div>
           </div>
        </div>

        {/* IG Header */}
        <div className="px-5 py-3 flex justify-between items-center bg-black z-10">
            <div className="flex items-center gap-1 cursor-pointer">
                <h1 className="text-[22px] font-bold tracking-tight text-white flex items-center gap-1">
                  raoprime_talk <div className="bg-red-500 w-2.5 h-2.5 rounded-full ml-1 border-2 border-black"></div>
                </h1>
                <ChevronDown className="w-4 h-4 text-white" />
            </div>
            <div className="flex gap-6 items-center">
                <SquarePen className="w-[26px] h-[26px] stroke-[1.8]" />
            </div>
        </div>

        {/* Search Bar */}
        <div className="px-4 pb-4 bg-black z-10">
           <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input 
                type="text" 
                placeholder="Search" 
                className="w-full bg-[#262626] rounded-xl py-2 pl-10 pr-4 text-[16px] text-white placeholder-gray-500 focus:outline-none focus:bg-[#303030] transition-colors"
              />
           </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto scrollbar-hide pb-safe-bottom">
            
            {/* Notes Tray */}
            <div className="pl-4 pb-6 flex gap-4 overflow-x-auto scrollbar-hide">
                {/* User Note */}
                <div className="flex flex-col items-center gap-1 flex-shrink-0 cursor-pointer">
                    <div className="relative">
                        <div className="w-[76px] h-[76px] rounded-full bg-[#262626] flex items-center justify-center">
                             <div className="w-[72px] h-[72px] rounded-full overflow-hidden bg-gray-800 flex items-center justify-center border border-black">
                                <span className="text-2xl">😎</span>
                             </div>
                        </div>
                        <div className="absolute -top-3 left-0 right-0 flex justify-center">
                             <div className="bg-white/90 text-black text-[11px] px-2.5 py-1 rounded-[14px] max-w-[80px] truncate shadow-sm font-medium">
                                Share a thought...
                             </div>
                        </div>
                         <div className="absolute bottom-0 right-0 bg-[#262626] rounded-full p-1 border-2 border-black">
                            <div className="w-4 h-4 bg-white rounded-full flex items-center justify-center">
                                <span className="text-black text-xs font-bold">+</span>
                            </div>
                        </div>
                    </div>
                    <span className="text-[13px] text-gray-400 font-normal">Your Note</span>
                </div>

                {/* Persona Notes */}
                {PERSONAS.map((p, i) => {
                    const notes = [
                        "Missing you! ❤️", "Gym time 💪", "Homework check! 📚", "Drink water 💧", "Hey handsome 😉", "Useless... 🙄", "Yoga day 🧘‍♂️", "MAGA! 🇺🇸"
                    ];
                    return (
                        <div key={p.id} className="flex flex-col items-center gap-1 flex-shrink-0 cursor-pointer" onClick={() => startText(p)}>
                            <div className="relative">
                                <div className="w-[76px] h-[76px] rounded-full bg-black flex items-center justify-center">
                                    <img src={p.avatar} alt={p.name} className="w-[72px] h-[72px] rounded-full object-cover border border-[#262626]" />
                                </div>
                                <div className="absolute -top-3 left-0 right-0 flex justify-center animate-scale-in" style={{animationDelay: `${i * 100}ms`}}>
                                    <div className="bg-white/90 text-black text-[11px] px-2.5 py-1 rounded-[14px] max-w-[85px] truncate shadow-sm font-medium">
                                        {notes[i] || "Hi!"}
                                    </div>
                                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-white/90 rotate-45 transform origin-center"></div>
                                </div>
                            </div>
                            <span className="text-[13px] text-white font-normal truncate w-20 text-center">{p.name.split(' ')[0]}</span>
                        </div>
                    );
                })}
            </div>

            {/* Tabs */}
            <div className="px-4 pb-2 flex items-center justify-between mb-1">
                 <div className="flex gap-5">
                    <button 
                        onClick={() => setActiveTab('primary')}
                        className={`text-[15px] font-bold transition-colors ${activeTab === 'primary' ? 'text-white' : 'text-gray-500'}`}
                    >
                        Messages
                    </button>
                    <button 
                        onClick={() => setActiveTab('general')}
                        className={`text-[15px] font-bold transition-colors ${activeTab === 'general' ? 'text-white' : 'text-gray-500'}`}
                    >
                        Requests <span className="text-red-500 ml-0.5">•</span>
                    </button>
                 </div>
            </div>

            {/* Message List */}
            <div className="flex flex-col pb-10">
               {PERSONAS.map((persona, idx) => (
                 <div 
                    key={persona.id} 
                    className="px-4 py-3 active:bg-[#1a1a1a] transition-colors cursor-pointer flex items-center justify-between group" 
                    onClick={() => startText(persona)}
                 >
                    <div className="flex items-center gap-3 overflow-hidden">
                       <div className="relative flex-shrink-0">
                          <img src={persona.avatar} alt={persona.name} className="w-14 h-14 rounded-full object-cover" />
                          {idx % 3 !== 0 && (
                              <div className="absolute bottom-0 right-0 w-[15px] h-[15px] bg-green-500 rounded-full border-[3px] border-black"></div>
                          )}
                       </div>
                       
                       <div className="flex-1 min-w-0">
                          <h3 className="text-[16px] text-white font-normal truncate flex items-center gap-1">
                            {persona.name}
                            {persona.isVerified && <VerifiedBadge />}
                          </h3>
                          <div className="flex items-center gap-1 text-gray-400 text-[14px]">
                             <p className="truncate max-w-[240px]">
                                {idx % 2 === 0 ? `Sent a reel by ${persona.name.split(' ')[0]}` : "Active 5m ago"}
                             </p>
                             {idx === 0 && <span className="w-1 h-1 bg-gray-500 rounded-full mx-1"></span>}
                             {idx === 0 && <span>1h</span>}
                          </div>
                       </div>
                    </div>
                 </div>
               ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default App;